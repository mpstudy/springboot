package hello;

import org.springframework.web.socket.WebSocketSession;

import java.util.HashMap;
import java.util.Map;

public class Room {
  private Map<String, WebSocketSession> sessionMap = new HashMap<String, WebSocketSession>();

  public void addUser(WebSocketSession client) {

  }

  public void sendMessage(String message) {

  }

  public void leaveUser(WebSocketSession client) {

  }
}
