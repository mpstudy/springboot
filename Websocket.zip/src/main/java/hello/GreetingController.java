package hello;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class GreetingController {

  @MessageMapping("/hello")
  @SendTo("/topic/greetings")
  public Greeting greeting(HelloMessage message) throws Exception {
    long time = System.currentTimeMillis();
    SimpleDateFormat dayTime = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
    String now = dayTime.format(new Date(time));

    StringBuilder builder = new StringBuilder();
    builder.append(now);
    builder.append(", ");
    builder.append(message.getName());
    builder.append(": ");
    builder.append(message.getMessage());

    return new Greeting(builder.toString());
  }
}
