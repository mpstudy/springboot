package hello;

public class ChatMessage {
  public static final int ROOM_ENTER = 100;
  public static final int ROOM_MESSAGE = 101;
  public static final int ROOM_LEAVE = 102;

  private int flag;
  private String sender;
  private String room;
  private String message;

  public ChatMessage(String text) {

  }

  public String getRoom(){
    return this.room;
  }

  public int getFlag(){
    return this.flag;
  }
}
