package hello;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.HashMap;
import java.util.Map;

@Component
public class ChatHandler extends TextWebSocketHandler{
  private Map<String, Room> rooms = new HashMap<String, Room>();
  private Map<String, String> sessions = new HashMap<String, String>();

  @Override
  public void afterConnectionEstablished(WebSocketSession session) throws Exception {
    System.out.println("Client Connected: " + session.getId() + " ,Address: " + session.getRemoteAddress());

  }

  @Override
  protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
    ChatMessage chatMessage = new ChatMessage(message.getPayload());
    Room room = rooms.get(chatMessage.getRoom());

    switch(chatMessage.getFlag()){
      case ChatMessage.ROOM_ENTER:
        break;
      case ChatMessage.ROOM_MESSAGE:
        break;
      case ChatMessage.ROOM_LEAVE:
        break;
      default:
        break;
    }
  }

  @Override
  public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {

  }
}
